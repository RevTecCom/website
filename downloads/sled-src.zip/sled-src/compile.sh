#!/bin/sh

OURPATH=$(dirname $(readlink -f "$0")) ; OLDPWD=$(pwd)

cd "$OURPATH/src"

/usr/bin/cc -Wall -c "file.c" "command.c" "parser.c"
/usr/bin/cc -Wall -o "$OURPATH/sled" "main.c" "file.o" "command.o" "parser.o"

/usr/bin/rm -f "file.o" "command.o" "parser.o"

cd "$OURPATH"

if [ "$1" = "mkdeb" ]
then
    /usr/bin/mkdir -p "$OURPATH/sled-$(uname -m)/DEBIAN"
    /usr/bin/mkdir -p "$OURPATH/sled-$(uname -m)/usr/bin"
    /usr/bin/mkdir -p "$OURPATH/sled-$(uname -m)/usr/share/doc/sled"

    /usr/bin/cp  "$OURPATH/sled" "$OURPATH/sled-$(uname -m)/usr/bin/sled"
    /usr/bin/cp "$OURPATH/LICENSE" "$OURPATH/sled-$(uname -m)/usr/share/doc/sled/LICENSE"

    "$OURPATH/sled" -f "$OURPATH/sled-$(uname -m)/DEBIAN/control" -c "Package: sled" > /dev/null
    "$OURPATH/sled" -f "$OURPATH/sled-$(uname -m)/DEBIAN/control" -c "Version: 1.0" > /dev/null
    "$OURPATH/sled" -f "$OURPATH/sled-$(uname -m)/DEBIAN/control" -c "Maintainer: Leah Pasiune" > /dev/null
    "$OURPATH/sled" -f "$OURPATH/sled-$(uname -m)/DEBIAN/control" -c "Architecture: amd64" > /dev/null
    "$OURPATH/sled" -f "$OURPATH/sled-$(uname -m)/DEBIAN/control" -c "Description: RTC Silly Line Editor" > /dev/null

    /usr/bin/dpkg-deb --build "$OURPATH/sled-$(uname -m)"
    /usr/bin/rm -r "$OURPATH/sled-$(uname -m)"
fi
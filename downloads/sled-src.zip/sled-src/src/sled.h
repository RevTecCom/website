//This code conforms to POSIX.1b (Real-time extensions) [popen/pclose]
#define _POSIX_C_SOURCE 199309L

#define SLED_BUFSIZ 32767
#define SLED_VERSIONSTR "1"
#define ethrow() {\
    printf("Error: %s, line %d - %s. Abort\n", __func__, __LINE__, __FILE__); \
    exit(EXIT_FAILURE); \
} while(0)

//Option flags
#define SLEDFLAG_HELP       0b10000000
#define SLEDFLAG_VERSION    0b01000000
#define SLEDFLAG_COMMAND    0b00100000

//Defined in file.c
int flist(FILE *file);
int flist_lno(FILE* file, long int begin, long int end);
int flineremove(FILE *file, int lno, char *filename);
int fseekline(FILE *file, long int lineno);
int fputsnoow(FILE *file, char *text, long int line, char* filename);
int flineremove_lno(FILE *file, long int begin, long int end, char *filename);

//Defined in parser.c
int inputparser1(char *input, long int *no);
int inputparser2(char *input, long int *no, char *string);
int inputparser3(char *input, long int *no, long int *no2);

//Defined in command.c
int sendpipetostring(char *dest, char* command);
int sendshelltotext(char* command, FILE *file, long int line, char* filename);
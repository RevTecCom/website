#include <stdio.h>
#include <string.h>
#include "sled.h"

//List all the contents of a file as text.
int flist(FILE *file){
    if(fseek(file, 0, SEEK_SET) == -1) return -1;
    
    long int currentline = 1;

    char stringbuffer[SLED_BUFSIZ] = {0};
    while (!feof(file))
    {
        strcpy(stringbuffer, "\0");
        fgets(stringbuffer, SLED_BUFSIZ - 1, file);
        printf("%ld, %s", currentline, stringbuffer);
        currentline++;
    }
    printf("\n");

    if(fseek(file, 0, SEEK_END) == -1) return -1;

    return 0;
}

int flist_lno(FILE *file, long int begin, long int end) {
    if(fseek(file, 0, SEEK_SET) == -1) return -1;
    
    long int currentline = 1;
    char stringbuffer[SLED_BUFSIZ] = {0};

    while (!feof(file))
    {
        strcpy(stringbuffer, "\0");
        fgets(stringbuffer, SLED_BUFSIZ - 1, file);
        if(currentline > begin -1 && currentline < end + 1) {
            printf("%ld, %s", currentline, stringbuffer);
        }
        currentline++;
    }
    printf("\n");

    if(fseek(file, 0, SEEK_END) == -1) return -1;

    return 0; 
}

int flineremove_lno(FILE *file, long int begin, long int end, char *filename) {
    FILE *tempfile = fopen("sled.tmp", "w");
    if(tempfile == NULL) return -1;

    if(fseek(file, 0, SEEK_SET) == -1) return -1;

    long int currentline = 1;
    char stringbuffer[SLED_BUFSIZ] = {0};

    while (!feof(file)){
        strcpy(stringbuffer, "\0");
        fgets(stringbuffer, SLED_BUFSIZ - 1, file);
        if(!(currentline > begin -1 && currentline < end + 1)) {
            fputs(stringbuffer, tempfile);
        }
        currentline++;
    }


    if(fclose(tempfile) == EOF) return -1;

    if(remove(filename) == -1) {
        rename("sled.tmp","sledfile-edited");
        return -1;
    }
    if(rename("sled.tmp", filename) == -1) return -1;
    if(freopen(filename, "r+", file) == NULL) return -1;
    if(fseek(file, 0, SEEK_END) == -1) return -1;

    return 0;   
}

//Remove a line from a file
/* If implementing this function elsewhere: remember it doesn't save
the previous position we were in in the file */
int flineremove(FILE* file, int lno, char *filename) {
    char stringbuffer[SLED_BUFSIZ] = {0};
    int thislno = 1;

    FILE *tempfile = fopen("sled.tmp", "w");
    if(tempfile == NULL) return -1;

    if(fseek(file, 0, SEEK_SET) == -1) return -1;
    
    while(!feof(file)){
        strcpy(stringbuffer, "\0");
        fgets(stringbuffer, SLED_BUFSIZ -1, file);
        if(lno != thislno){
            fputs(stringbuffer, tempfile);
        }
        thislno++;
    }

    if(fclose(tempfile) == EOF) return -1;
    if(remove(filename) == -1) {
        rename("sled.tmp","sledfile-edited");
        return -1;
    }
    if(rename("sled.tmp", filename) == -1) return -1;
    if(freopen(filename, "r+", file) == NULL) return -1;
    if(fseek(file, 0, SEEK_END) == -1) return -1;

    return 0;
}

//Seek to the beginning of a line
int fseekline(FILE *file, long int lineno){
    char stringbuffer[SLED_BUFSIZ] = {0};
    if(fseek(file, 0, SEEK_SET) == -1) return -1;

    for(int i = 1; i < lineno; i++) {
        if(!feof(file)){
            strcpy(stringbuffer, "\0");
            fgets(stringbuffer, SLED_BUFSIZ - 1, file);
        }
    }

    return 0;
}

//Add a new line without overwrite
int fputsnoow(FILE *file, char *text, long int line, char* filename){
    char stringbuffer[SLED_BUFSIZ] = {0};
    int thislno = 1;

    FILE *tempfile = fopen("sled.tmp", "w");
    if(tempfile == NULL) return -1;

    if(fseek(file, 0, SEEK_SET) == -1) return -1;

    while(!feof(file)){
        strcpy(stringbuffer, "\0");
        fgets(stringbuffer, SLED_BUFSIZ -1, file);

        fputs(stringbuffer, tempfile);

        if(line == thislno){
            fputs(text, tempfile);
            fputc('\n', tempfile);
        }

        thislno++;
    }

    if(fclose(tempfile) == EOF) return -1;
    if(remove(filename) == -1) {
        rename("sled.tmp","sledfile-edited");
        return -1;
    }
    if(rename("sled.tmp", filename) == -1) return -1;
    if(freopen(filename, "r+", file) == NULL) return -1;
    if(fseek(file, 0, SEEK_END) == -1) return -1;

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sled.h"

//Standard input parser (int)
int inputparser1(char *input, long int *no) {
    *no = 0;
    char *token;
    
    if(strlen(input) > 3){
        token = strtok(input, " ");
        if(token == NULL) return -1;
        token = strtok(NULL, " ");
        if(token == NULL) {
            return -1;
        }
    } else {
        return -1;
    }

    *no = atoi(token);
    if(*no <= 0) {
        return -1;
    }

    return 0;
}

//Second input parser (int + string)
int inputparser2(char *input, long int *no, char *string){
    *no = 0;
    char *token;
    
    if(strlen(input) > 5){
        token = strtok(input, " ");
        if(token == NULL) return -1;
        token = strtok(NULL, " ");
        if(token == NULL) return -1;

        *no = atoi(token);
        if(*no <= 0) {
            return -1;
        }

        //Curious trick: if we leave the delimiter empty,
        //it merely returns the rest of the string!
        token = strtok(NULL, "");
        if(token == NULL) return -1;

        strcpy(string, token);
    } else {
        return -1;
    }

    return 0;
}

//Third input parser (int + int)
int inputparser3(char *input, long int *no, long int *no2){
    *no = 0;
    *no2 = 0;

    char *token;
    
    if(strlen(input) > 5){
        token = strtok(input, " ");
        if(token == NULL) return -1;
        token = strtok(NULL, " ");
        if(token == NULL) return -1;

        *no = atoi(token);
        if(*no <= 0) {
            return -1;
        }

        token = strtok(NULL, " ");
        if(token == NULL) return -1;

        *no2 = atoi(token);
        if(*no2 <= 0) {
            return -1;
        }
    } else {
        return -1;
    }

    return 0;
}
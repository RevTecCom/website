/*RTC Silly Line Editor (c) 2022 Leah Pasiune
The RTC Silly Line Editor is Common Software: you can redistribute it and/or modify it under the terms of
the Commons Protection License, Version 2, as published by the Revolutionary Technical Committee.
See the LICENSE file for details.*/

/*Programmer beware!
Before you try to read, or Marx forbid - modify this code, repeat along with me:
THERE IS NO HEAP, THERE IS NO HEAP, THERE IS NO HEAP*/

#include <linux/limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <termios.h>
#include <errno.h>
#include "sled.h"

void neuterer(int signal){
    printf(" - Unsupported signal.\n");
}

//Program
int main(int argc, char** argv) {
    //Trap SIGKILL
    signal(SIGINT, neuterer);

    //Trap EOF
    {
        struct termios t;
        if(tcgetattr(STDIN_FILENO, &t) != 0){
            printf("Could not read attributes from stdin.\n");
            exit(EXIT_FAILURE);
        }

        t.c_cc[VEOF] = _POSIX_VDISABLE;
        if(tcsetattr(STDIN_FILENO, TCSANOW, &t) != 0){
            printf("Could not set attributes for stdin.\n");
            exit(EXIT_FAILURE);
        }
    }

    char flags = 0b00000000;
    char go_input[ARG_MAX] = {0};
    char filename[ARG_MAX] = {0};
    {
        char go_option = 0;
        while(go_option != -1) {
            go_option = getopt(argc, argv, ":vh:c:f:");
            switch (go_option) {
                case 'v':
                    flags |= SLEDFLAG_VERSION;
                break;
                case 'h':
                    flags |= SLEDFLAG_HELP;
                break;
                case 'c':
                    flags |= SLEDFLAG_COMMAND;
                    strncpy(go_input, optarg, ARG_MAX - 2);
                break;
                case 'f':
                    strncpy(filename, optarg, ARG_MAX - 2);
                break;
            }
        }
    }

    if(flags & SLEDFLAG_VERSION){
        printf("RTC Silly Line Editor (sled) version %s\nLicense CmPLv2: Commons Protection License, Version 2. See LICENSE file.\nThis is Common Software, you may redistribute and use it under certain conditions that guarantee the safety of the commons.\nThere is NO WARRANTY, to the extent permitted by law.\n", SLED_VERSIONSTR);
        exit(EXIT_SUCCESS);
    }
    if((flags & SLEDFLAG_HELP) || argc <= 1){
        printf("sled -f [filename] (-c \"[command]\")\n\n?h - Show copyright and further help;\n?H - Show this text;\n?q - Quit the program;\n?s - Save file;\n?l - List file;\n?L [begin] [end] - List file from line begin to line end;\n?c [line] [command] - Pipe shell output to line;\n?e [lineno] - Erase line at lineno;\n?E [begin] [end] - Delete lines from begin to end;\n?w [lineno] [text] - Add new line after lineno containing text;\n?p [offset] - Seek to byte to destructively insert;\n?P - Seek to line to destructively insert.\n\n");
        exit(EXIT_SUCCESS);
    }

    //Create file for reading and writing if it doesn't exist, open it if it does.
    FILE* mainfile;

    {
        struct stat dummy; //passing NULL is uns. behaviour
        if(stat(filename, &dummy) == -1) {
            mainfile = fopen(filename, "w+");
        } else {
            mainfile = fopen(filename, "r+");
            fseek(mainfile, 0, SEEK_END);
        }
        if(mainfile == NULL) {
            printf("Could not open file or no file input.\n");
            exit(EXIT_FAILURE);
        }
    }

    //Print text
    if(!(flags & SLEDFLAG_COMMAND)){
        printf("\n\nRTC Silly Line Editor - sled\n'?q' for quitting, '?h for help.\n");
    }

    //Main program loop
    long int lastlinesize;
    while(1) {
        char input[SLED_BUFSIZ] = {0};

        //Relating to erase function.
        long int e_lineno;

        //Relating to point char function.
        long int m_seekno;

        //Relating to point line function.
        long int ml_seekno;

        //Relating to second line list function
        long int l_lineno1;
        long int l_lineno2;

        //Relating to second line delete function
        long int e2_lineno1;
        long int e2_lineno2;

        //Relating to write on line function.
        long int w_lineno;
        char w_text[SLED_BUFSIZ] = {0};

        //Relating to command output function.
        long int c_lineno;
        char c_text[SLED_BUFSIZ] = {0};

        //get input
        if(flags & SLEDFLAG_COMMAND) {
            strcpy(input, go_input);
        } else {
            fgets(input, SLED_BUFSIZ - 1, stdin);
            input[strcspn(input, "\n")] = '\0';
        }
        
        if(input[0] == '?') {
            switch (input[1]) {
                //quit
                case 'q':
                    fclose(mainfile);
                    exit(EXIT_SUCCESS);
                break;
                //save
                case 's':
                    if(freopen(filename, "r+", mainfile) == NULL) {
                        printf("Failed to save.\n");
                    }
                    if(fseek(mainfile, 0, SEEK_END) == -1) ethrow();
                break;
                case 'l':
                    if(flist(mainfile) == -1) ethrow();
                break;
                case 'L':
                    l_lineno1 = 0;
                    l_lineno2 = 0;

                    if(inputparser3(input, &l_lineno1, &l_lineno2) == -1){
                        printf("Error!\n");
                        break;
                    }

                    //Execute
                    if(flist_lno(mainfile, l_lineno1, l_lineno2) == -1) ethrow();
                break;
                case 'e':
                    e_lineno = 0;

                    if(inputparser1(input, &e_lineno) == -1){
                        printf("Error!\n");
                        break;
                    }

                    //Execute
                    if(flineremove(mainfile, e_lineno, filename) == -1) ethrow();
                break;
                case 'E':
                    e2_lineno1 = 0;
                    e2_lineno2 = 0;

                    if(inputparser3(input, &e2_lineno1, &e2_lineno2) == -1){
                        printf("Error!\n");
                        break;
                    }

                    if(flineremove_lno(mainfile, e2_lineno1, e2_lineno2, filename) == -1) ethrow();
                break;
                case 'w':
                    w_lineno = 0;
                    strcpy(w_text, "\0");

                    if(inputparser2(input, &w_lineno, w_text) == -1){
                        printf("Error!\n");
                        break;
                    }

                    //Execute
                    if(fputsnoow(mainfile, w_text, w_lineno, filename) == -1) ethrow();
                break;
                case 'p':
                    m_seekno = 0;

                    if(inputparser1(input, &m_seekno) == -1){
                        printf("Error!\n");
                        break;
                    }
                    
                    /*Most errors with fseek have to do with invalid seeks,
                    and do not cause any weird behaviour, so we merely just
                    print the error number*/
                    if(fseek(mainfile, m_seekno, SEEK_CUR) == -1) {
                        printf("fseek error number %d\n", errno);
                    }
                break;
                case 'P':
                    ml_seekno = 0;

                    if(inputparser1(input, &ml_seekno) == -1) {
                        printf("Error!\n");
                        break;
                    }

                    if(fseekline(mainfile, ml_seekno) == -1) ethrow();
                break;
                case 'c':
                    c_lineno = 0;
                    strcpy(c_text, "\0");

                    if(inputparser2(input, &c_lineno, c_text) == -1){
                        printf("Error!\n");
                        break;
                    }

                    //Execute
                    if(sendshelltotext(c_text, mainfile, c_lineno, filename) == -1) ethrow();
                break;
                case 'h':
                    printf("\nRTC Silly Line Editor - sled\nRTC Silly Line Editor (c) 2022 Leah Pasiune\nThe RTC Silly Line Editor is Common Software: you can redistribute it and/or modify it under the terms of\nthe Commons Protection License, Version 2, as published by the Revolutionary Technical Committee.\nSee the LICENSE file for details.\nThere is NO WARRANTY, to the full extent permitted by law.\n\nFor operation information, see '?H' (with an uppercase).\n");
                break;
                case 'H':
                    printf("\n?h - Show copyright and further help;\n?H - Show this text;\n?q - Quit the program;\n?s - Save file;\n?l - List file;\n?L [begin] [end] - List file from line begin to line end;\n?c [line] [command] - Pipe shell output to line;\n?e [lineno] - Erase line at lineno;\n?E [begin] [end] - Delete lines from begin to end;\n?w [lineno] [text] - Add new line after lineno containing text;\n?p [offset] - Seek to byte to destructively insert;\n?P - Seek to line to destructively insert.\n\n");
                break;
            }
        } else {
            //write text normally
            if(fputs(input, mainfile) == EOF){
                printf("Could not write!\n");
            } else {
                lastlinesize = strlen(input);
                printf("Characters written: %ld\n", lastlinesize);
                fputc('\n', mainfile);
                freopen(filename, "r+", mainfile);
                fseek(mainfile, 0, SEEK_END);
            }
        }

        if(flags & SLEDFLAG_COMMAND){
            exit(EXIT_SUCCESS);
        }
    }
}
#include <stdio.h>
#include <string.h>
#include "sled.h"

//Pass pipe to string
int sendpipetostring(char *dest, char* command) {
    FILE *pipe = popen(command, "r");
    if(pipe == NULL) return -1;

    char stringbuffer[SLED_BUFSIZ] = {0};

    while(fgets(stringbuffer, SLED_BUFSIZ - 1, pipe) != NULL) {
        strcat(dest, stringbuffer);
    }

    pclose(pipe);
    return 0;
}

//Get shell output and paste into line
int sendshelltotext(char* command, FILE *file, long int line, char* filename) {
    char stringtoreceive[SLED_BUFSIZ] = {0}; // Can't put an uninitialized val. through strcat()
    
    if(sendpipetostring(stringtoreceive, command) == -1) return -1;
    if(fputsnoow(file, stringtoreceive, line, filename) == -1) return -1;

    return 0;
}
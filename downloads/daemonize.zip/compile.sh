#!/bin/sh

OURPATH=$(dirname $(readlink -f "$0")) ; OLDPWD=$(pwd)

/usr/bin/cc -Wall -c -o "$OURPATH/daemonize.o" "$OURPATH/daemonize.c" -fPIC
/usr/bin/ar r "$OURPATH/daemonize.a" "$OURPATH/daemonize.o"

/usr/bin/rm -f "$OURPATH/daemonize.o"
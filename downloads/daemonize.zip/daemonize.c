/*Copyright (c) 2022 Leah Pasiune. All rights reserved.  
  
RTC Daemonize is common software: you can redistribute it and/or modify it under the terms of the Commons Protection License, Version 2, as published by the Revolutionary Technical Committee.  
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the Commons Protection License for more details.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#define DMN_USING_RUN               0b10000000
#define DMN_DEFAULT                 0b01000000
#define DMN_NO_CLOSE                0b00100000
#define DMN_KEEP_SIGNAL_HANDLERS    0b00010000
#define DMN_NO_CHDIR                0b00001000
#define DMN_NO_UMASK                0b00000100

typedef unsigned long ulong;

pid_t daemonize(char flags) {

    if(!(flags & DMN_NO_CLOSE)) {
        struct rlimit rl;

        getrlimit(RLIMIT_NOFILE, &rl);
        for(ulong fil = 4; fil < rl.rlim_cur; fil++) {
            if(fcntl(fil, F_GETFD) != -1) {
                close(fil);
            }
        }
    }

    /* Reset all signals to SIG_DFL,
    create a new signal mask, empty it and then set it.*/
    if(!(flags & DMN_KEEP_SIGNAL_HANDLERS)) {
        for (int sgn = 0; sgn < _NSIG; sgn++){
            signal(sgn, SIG_DFL);
        }

        sigset_t newmask;
        sigemptyset(&newmask);
        if(sigprocmask(SIG_SETMASK, &newmask, NULL) == -1){
            return -1;
        }
    }

    // Fork for the first time.
    pid_t pid = fork();
    if(pid < 0) return -1;
    if(pid > 0) exit(EXIT_SUCCESS);
    
    if(setsid() == -1) return -1;

    // Fork for the second time
    pid = fork();
    if(pid < 0) return -1;
    if(pid > 0) exit(EXIT_SUCCESS);

    // In the daemon, point the standard streams to /dev/null.
    if(!(flags & DMN_NO_CLOSE)) {
        freopen("/dev/null", "r", stdin);
        freopen("/dev/null", "w", stdout);
        freopen("/dev/null", "w", stderr);
    }

    // Set the umask to 0 and then go to the root directory.
    if(!(flags & DMN_NO_UMASK)) umask(0);
    if(!(flags & DMN_NO_CHDIR)) chdir("/");

    return getpid();
}

pid_t rundaemon(char flags, int (*daemon_func)(void *udata), void *udata, int *exit_code, char *pid_file_path) {
    // Check if daemon is already running.
    FILE* fdcheck;

    fdcheck = fopen(pid_file_path, "r");
    if(fdcheck != NULL) {
        char pidstr[7];
        fgets(pidstr, 6, fdcheck);
        fclose(fdcheck);

        pid_t procpid = atoi(pidstr);
        if(kill(procpid, 0) == 0) {
            return -2;
        }
    }

    // Daemonize
    pid_t dpid = daemonize(flags);

    //Write PID file. For some reason, only C-style files work!
    FILE* fd2;

    fd2 = fopen(pid_file_path, "w");
    if(fd2 != NULL) {
        char ourpid[7];
        snprintf(ourpid, 6, "%d", dpid);
        fputs(ourpid, fd2);

        fclose(fd2);
    }

    // Run main daemon function.
    *exit_code = (*daemon_func)(udata);

    // Remove PID file
    remove(pid_file_path);

    // Return PID of daemon
    return dpid;
}
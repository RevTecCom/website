#include <sys/types.h>

#ifndef _DAEMONIZE_H
    #define _DAEMONIZE_H
#endif

#define DMN_USING_RUN               0b10000000
#define DMN_DEFAULT                 0b01000000
#define DMN_NO_CLOSE                0b00100000
#define DMN_KEEP_SIGNAL_HANDLERS    0b00010000
#define DMN_NO_CHDIR                0b00001000
#define DMN_NO_UMASK                0b00000100

pid_t daemonize(char flags);
pid_t rundaemon(char flags, int (*daemon_func)(void *udata), void *udata, int *exit_code, char *pid_file_path);